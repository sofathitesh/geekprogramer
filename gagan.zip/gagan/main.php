<?php
session_start();
if(isset($_SESSION['uname']) && isset($_SESSION['pass']))
{
echo "<a href='logout.php'>LOGOUT</a>";
echo "<form action='main.php' method='post'>";
echo "<table align='center'>";
echo "<tr><th>ENTER THE DATA</th></tr>";
echo "<tr><td>ENTER Student Name</td><td><input type='text' name='t2'></td></tr>";
echo "<tr><td>ENTER RollNo</td><td><input type='text' name='t3'></td></tr>";
echo "<tr><td>ENTER Class</td><td><input type='text' name='t4'></td></tr>";
echo "<tr><td>ENTER college</td><td><input type='text' name='t5'></td></tr>";
echo "<tr><td>ENTER mobile</td><td><input type='text' name='t6'></td></tr>";
echo "<tr><td>ENTER address</td><td><input type='text' name='t7'></td></tr>";
echo "<tr><td>ENTER FatherName</td><td><input type='text' name='t11'></td></tr>";

echo "<tr><td><input type='submit' name='ok' value='INSERT'></td></tr></table></form>";
if(isset($_POST['ok']))
{
if(strlen($_POST['t3'])>0)
{
						$con=mysql_connect("localhost","root","exDB1");
				mysql_select_db("fg",$con);
				$qry="insert into datas values('".$_POST['t2']."','".$_POST['t11']."','".$_POST['t3']."','".$_POST['t4']."','".$_POST['t5']."','".$_POST['t6']."','".$_POST['t7']."')";
				$res=mysql_query($qry);
				echo "DATA IS ADDED";
}else
{
}
}
}
else
{
	echo "please login";
}
?>
