<?php
echo "<a href='login.php'>LOGIN</a>";
echo "<h3>REGISTRATION</h3>";
echo "<form action='index.php' method='post' >";
echo "<table>";
echo "<tr><td>ENTER USERNAME</td><td><input type='text' name='t1'></td></tr>";
echo "<tr><td>ENTER PASSWORD</td><td><input type='password' name='t2'></td></tr>";
echo "<tr><td><input type='submit' value='OK'></td></tr></table></form>";
if(isset($_POST['t1']))
{
	if(isset($_POST['t2']))
	{
		if(strlen($_POST['t1'])>4)
		{
			
			if(strlen($_POST['t2'])>4)
			{
				$con=mysql_connect("localhost","root","expDB1");
				mysql_select_db("fg",$con);
				$qry="insert into user values('".$_POST['t1']."','".$_POST['t2']."')";
				$res=mysql_query($qry);
				echo "ok YOU now register";
				header("location:login.php");
			}else
			{
		echo 		"Enter the pass minimum 5 char";
			}
		}else{
		echo "Enter the name minimum 5 char";
		}
	}else
	{
			echo 		"Enter the pass minimum 5 char";
	}
}else
{
	echo "ENTER THE USER NAME";
}
?>
