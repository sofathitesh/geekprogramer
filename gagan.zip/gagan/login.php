<?php
echo "<h3>NOW LOGIN</h3>";
echo "<form action='login.php' method='post' >";
echo "<table>";
echo "<tr><td>ENTER USERNAME</td><td><input type='text' name='t1'></td></tr>";
echo "<tr><td>ENTER PASSWORD</td><td><input type='password' name='t2'></td></tr>";
echo "<tr><td><input type='submit' value='OK'></td></tr></table></form>";
if(isset($_POST['t1']))
{
	session_start();
	if(isset($_POST['t2']))
	{
		if(strlen($_POST['t1'])>4)
		{
			
			if(strlen($_POST['t2'])>4)
			{
				$con=mysql_connect("localhost","root","sofat");
				mysql_select_db("fg",$con);
				$qry="select * from user where username='".$_POST['t1']."'";
				$res=mysql_query($qry);
				$data=mysql_fetch_array($res);
				if(mysql_num_rows($res)!=0)
				{
				if($data['username']==$_POST['t2'])
				{
					header("location:main.php");
					$_SESSION['uname']=$_POST['t1'];
					$_SESSION['pass']=$_POST['t2'];
				}else{
				echo "YOU ENTER WORNG PASSWORD";
				}
}else{
echo "user not found";
}				
			}else
			{
		echo 		"Enter the password";
			}
		}else{
		echo "Enter the name";
		}
	}else
	{
			echo 		"Enter the password";
	}
}else
{
	echo "ENTER THE USER NAME";
}
?>
